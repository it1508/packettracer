/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.c
 * Author: student
 *
 * Created on 6. listopadu 2018, 10:57
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#define INPUT "pokus.txt"
#define LINE_LENGTH 200
#define DELIM " .,/:=\n"

typedef struct{
    char *word;
    int count;
} WORD;


/*
 * 
 */

char* toLow(char * str){
    char * string = NULL;
    int i;
    int delka = strlen(str);
    string = (char*)malloc(sizeof(char)*delka);
    for(i=0;i<strlen(str);i++){
        string[i]=tolower(str[i]);
    }

    return string;
    
}


int main(int argc, char** argv) {
    
    
    
    FILE *input;
    WORD *words = NULL;
    int pocetSlov = 0, i;
    int test = 0;
    int exist = 0;
    int sorted = 1;
    char *slovo;
    char line[LINE_LENGTH];
    input = fopen(INPUT,"r");
    
    
    if(input == NULL){
        printf("Cannot read file %s\n", INPUT);
        return(EXIT_FAILURE);
    }
    
    while(fgets(line,LINE_LENGTH,input)!=NULL){
        slovo = strtok(line,DELIM);
        
        if(pocetSlov==0){
            words = (WORD*)malloc(sizeof(WORD));

            if(words != NULL && slovo != NULL){
                words[0].word = NULL;
                words[0].word = (char*)malloc(sizeof(char)*strlen(slovo));
                strcpy(words[0].word, slovo);
                pocetSlov++;
                words[0].count = 1;
                
            }
            
        }
        
        while(slovo != NULL){
            if(pocetSlov > 0){
                for(i=0;i<pocetSlov; i++){
                    if(strcmp(toLow(slovo), toLow(words[i].word)) == 0){
                        words[i].count++;
                        exist = 1;
                    }else{
                        exist = 0;
                    }
                }
                if(!exist){
                        words = (WORD*)realloc(words,sizeof(WORD)*(pocetSlov+1));
                        words[pocetSlov].word = NULL;
                        words[pocetSlov].word = (char*)malloc(sizeof(char) * strlen(slovo));
                        words[pocetSlov].count = 1;
                        if(words[pocetSlov].word!=NULL){
                            strcpy(words[pocetSlov].word, slovo);
                            pocetSlov++;
                        }
                }
                exist = 0;
            }else
                pocetSlov++;
            slovo = strtok(NULL, DELIM);
        }
        
        
        
        

    }
    printf("Celkovy pocet slov: %d\n", pocetSlov);
    char *temp=NULL;
    char tempCount;
    
    /*
    while(sorted){
        sorted = 0;
        for(i=0;i<pocetSlov;i++){
            if(words[i].count < words[i+1].count){
                sorted = 1;
                
                temp = (char*)realloc(temp,strlen(words[i].word)*sizeof(char));
                if(temp != NULL)
                    strcpy(temp,words[i].word);
                tempCount = words[i].count;
                
                words[i].word = NULL;
                words[i].word = (char*)realloc(words[i].word, strlen(words[i+1].word)*sizeof(char));
                strcpy(words[i].word, words[i+1].word);
                words[i].count = words[i+1].count;
                
                words[i+1].word = NULL;
                words[i+1].word = (char*)realloc(words[i+1].word, strlen(temp)*sizeof(char));
                
                strcpy(words[i+1].word, temp);
                words[i+1].count = tempCount;
                
            }
        }
    }*/
    
        for(i=0;i<pocetSlov;i++){
            if(words[i].count > 1)
            printf("%s - %d\n",words[i].word,words[i].count);
        }
    
    
     if(words!=NULL){
            for(i=0;i<pocetSlov;i++){
                if(words[i].word!= NULL){
                    free(words[i].word);
                    words[i].word = NULL;
                }
                    
            }
            free(words);
            words = NULL;   
        }
    
    
    
    
    
    
    

    return (EXIT_SUCCESS);
}

